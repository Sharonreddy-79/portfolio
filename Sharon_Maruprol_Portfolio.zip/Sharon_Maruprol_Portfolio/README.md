# Sharon Maruprol — Portfolio Website

A responsive, single-page personal portfolio built with HTML, CSS, and JavaScript.

## Run locally
1. Extract this folder.
2. Open `index.html` in a browser.
3. Edit the content directly in `index.html` using VS Code.

## Important before publishing
- Replace the placeholder LinkedIn and GitHub links with your real profile URLs.
- If you want a Resume button, place a PDF copy of your resume in this folder and add a link to it.
- Only describe projects and skills you can confidently explain in an interview.
- Check that your email and phone number are the contact details you want public.

## Deploy for a live demo
You can publish this static website with GitHub Pages, Netlify, or Vercel. For a hackathon submission, include the live URL and a GitHub repository URL if the submission form allows them.
